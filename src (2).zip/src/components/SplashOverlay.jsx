// src/components/SplashOverlay.jsx
import React, { useEffect, useState } from "react";

function isMobileViewport() {
  if (typeof window === "undefined") return false;
  return window.matchMedia("(max-width: 768px)").matches || /Mobi|Android|iPhone|iPad/i.test(navigator.userAgent);
}

function seenRecently() {
  try {
    const raw = localStorage.getItem("splashSeenAt");
    if (!raw) return false;
    const last = Number(raw);
    // show at most once every 12 hours
    return Date.now() - last < 12 * 60 * 60 * 1000;
  } catch {
    return false;
  }
}

export default function SplashOverlay({ skipIfAuthenticated = false, durationMs = 1500 }) {
  const [show, setShow] = useState(false);
  const [fade, setFade] = useState(false);

  useEffect(() => {
    if (skipIfAuthenticated) return;               // don't block already-signed-in flow
    if (!isMobileViewport()) return;               // only on mobile
    if (seenRecently()) return;                    // throttle repeats

    setShow(true);
    const t1 = setTimeout(() => setFade(true), Math.max(300, durationMs - 300));
    const t2 = setTimeout(() => {
      setShow(false);
      try { localStorage.setItem("splashSeenAt", String(Date.now())); } catch {}
    }, durationMs);

    return () => { clearTimeout(t1); clearTimeout(t2); };
  }, [skipIfAuthenticated, durationMs]);

  if (!show) return null;

  return (
    <div
      className={`splash-root ${fade ? "splash-fade" : ""}`}
      role="img"
      aria-label="Loading"
    >
      <div className="splash-overlay">
        {/* Optional logo / title */}
        <div className="splash-brand">
          <img src="/favicon.ico" alt="" className="splash-logo" />
          <div className="splash-title">Kart Force</div>
        </div>
      </div>
    </div>
  );
}
