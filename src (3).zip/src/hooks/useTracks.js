// src/hooks/useTracks.js
import { useEffect, useState } from "react";
import { db } from "../firebase";
import { collection, getDocs, orderBy, query } from "firebase/firestore";

/**
 * Loads /tracks once for simple forms (pre-auth friendly if rules allow read).
 * Each item returns { id, value, label, ...data }.
 */
export function useTracks() {
  const [tracks, setTracks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    (async () => {
      try {
        const q = query(collection(db, "tracks"), orderBy("displayName"));
        const snap = await getDocs(q);
        const rows = snap.docs.map((d) => {
          const data = d.data() || {};
          return {
            id: d.id,
            value: data.id || d.id,              // e.g. "SyringaPark"
            label: data.displayName || d.id,     // pretty name
            ...data,
          };
        });
        setTracks(rows);
      } catch (e) {
        console.error("Failed to load tracks:", e);
        setError(e?.message || "Failed to load tracks");
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  return { tracks, loading, error };
}
