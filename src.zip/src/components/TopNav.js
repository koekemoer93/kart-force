// src/components/TopNav.js
import React from 'react';
import './TopNav.css';

function TopNav({ role, onLogout }) {
  const trackButtons = [
    'Syringa Park',
    'IndyKart Clearwater',
    'IndyKart Eastgate',
    'IndyKart Mall of the South',
    'IndyKart Parkview',
    'RBEK',
    'Epic Pavilion',
    'Epic Midlands'
  ];

  return (
    <div className="top-nav">
      <div className="logo-text">Kart Force</div>

      {(role === 'admin' || role === 'owner') && (
        <>
          <div className="middle">
            {trackButtons.map((track, index) => (
              <button key={index} className="nav-button">
                {track}
              </button>
            ))}
          </div>

          <button className="logout-button" onClick={onLogout}>
            Logout
          </button>
        </>
      )}
    </div>
  );
}

export default TopNav;
